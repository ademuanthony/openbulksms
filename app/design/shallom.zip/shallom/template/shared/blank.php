<?php
/**
 * Created by PhpStorm.
 * User: Tony
 * Date: 4/7/2015
 * Time: 10:01 AM
 */
?>
<h2 style="text-align: center; margin: 100px;">Page layout not found</h2>